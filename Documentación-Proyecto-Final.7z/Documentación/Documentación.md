Universidad Mariano Galvez

Ingeniería en sistemas

Administración de tecnologías de la información

Inge. Melvin Calí











Proyecto Final










Gari Lester Mendoza Bedoya 7690-17-14228

Selvin Omar Castellanos 7690-17-14269

José Pablo Araiz 7690-17-9477

**Proyecto Final**

Según los indicado para el proyecto Final de Administración lo primero que se realizo fue un canal en Slack donde estuviera enlazado con Trello y donde se llevaría el control de crear las tareas y además asignarlas a los responsables. Como se solicito se adjuntan las capturas de Slack con lo que se realizó:

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.001.png)

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.002.png)

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.003.png)

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.004.png)

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.005.png)




![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.006.png)

El resultado en Trello sería el siguiente:

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.007.png)

Lo siguiente que se realizo fue investigar un API para analizar las peticiones de los usuarios, dando acciones para algunos términos como solicitar los horarios, precios, tallas, mostrar camisas, mostrar pantalones, saludos y el Chatbot daría una respuesta según lo solicitado.  Se utilizo una herramienta llamada Dialogflow para llevar un flujo según sean las interacciones del usuario.

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.008.png)

Cuando un usuario manda un mensaje con alguna de las palabras debe ejecutar el código de la palabra clave donde realizara una acción por ejemplo al utilizar la palabra mostrar-camisas debe de ejecutar el siguiente código.

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.009.png)

Dentro del código debe de tener una acción siguiendo con el ejemplo de mostrar-camisas debería de desplegar un catalogo de las prendas que están disponibles y que sean referentes a lo solicitado en este caso deben de ser camisas.


![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.010.png)

La herramienta de Dialogflow es bastante potente ya que permite la comunicación con diferentes plataformas como Facebook, Telegram, etc. Lo que cambiaria en estos casos seria la sintaxis, pero la lógica del código seria la misma.

El API que se utilizó fue GoodFatherBot que es especialmente para Telegram y lo que hace es permitir las conexiones entre DialogFlow con Telegram, es así como el Chatbot obtiene las acciones que debe de realizar.

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.011.png)

El recorrido del App como Chatbot sería el siguiente

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.012.png)

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.013.png)

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.014.png)

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.015.png)

![](Aspose.Words.839776df-7bf1-4a69-8c8d-08757048dca1.016.png)

El código que se utilizo para realizar las opciones del Chatbot es el siguiente:

{

`  `"telegram": {

`    `"text": "Con gusto, te ofrecemos las siguientes categorías de ropa, por favor elige una:",

`    `"reply\_markup": {

`      `"inline\_keyboard": [

`        `[

`          `{

`            `"callback\_data": "mostrar-camisas",

`            `"text": "Camisas"

`          `}

`        `],

`        `[

`          `{

`            `"callback\_data": "mostrar-pantalones",

`            `"text": "Pantalones"

`          `}

`        `]

`      `]

`    `}

`  `}

}



Luego se cargó la documentación y el código de la aplicación en el repositorio que se creo en la nube de Github

[GitHub - JaraizL/pr-Final_Admon: Proyecto Final - Administración de Tecnologías](https://github.com/JaraizL/pr-Final_Admon)

